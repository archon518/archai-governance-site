'use strict';

/**
 * AGENTUM™ — Execution & Orchestration Driver
 * ARCHAI™ Governance Framework · Barkdale & Co.
 * Credential: ARCH-DA-001-2026
 *
 * Governs how actions are sequenced, routed, and processed across
 * live active capability pipelines. Translates validated intent into
 * governed operational execution. No action routes without a valid
 * INTENTUM record.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const AGENTUM_VERSION = '1.0.0';
const ALGORITHM = 'sha256';
const ENCODING = 'hex';

// ── PIPELINE REGISTRATION ─────────────────────────────────────────────────────

const _pipelines = new Map();

function registerPipeline(pipelineDescriptor) {
  const { id, name, steps, authority, metadata = {} } = pipelineDescriptor;
  if (!id || !name || !Array.isArray(steps) || steps.length === 0) {
    throw new AgentumError('PIPELINE_INVALID', 'Pipeline requires id, name, and at least one step.');
  }
  const pipeline = {
    id, name, steps, authority: authority || 'Barkdale & Co.',
    registeredAt: Date.now(), metadata, status: 'ACTIVE', mechanism: 'AGENTUM',
  };
  _pipelines.set(id, pipeline);
  return pipeline;
}

function getPipeline(pipelineId) {
  if (!_pipelines.has(pipelineId)) {
    throw new AgentumError('PIPELINE_NOT_FOUND', `No pipeline registered with id: ${pipelineId}`);
  }
  return _pipelines.get(pipelineId);
}

function listPipelines() {
  return Array.from(_pipelines.values());
}

// ── ACTION ROUTING ────────────────────────────────────────────────────────────

/**
 * Routes an action through a governed pipeline.
 * Requires a validated INTENTUM record — no intent, no routing.
 *
 * @param {object} intentValidation - Result from INTENTUM.validateIntent()
 * @param {string} pipelineId - Target pipeline
 * @param {object} payload - Action payload
 * @returns {object} routeRecord
 */
function routeAction(intentValidation, pipelineId, payload = {}) {
  if (!intentValidation || !intentValidation.valid) {
    throw new AgentumError(
      'ROUTE_INVALID_INTENT',
      `Cannot route action: intent validation failed. Reason: ${intentValidation?.reason || 'UNKNOWN'}`
    );
  }

  const pipeline = getPipeline(pipelineId);

  if (pipeline.status !== 'ACTIVE') {
    throw new AgentumError('ROUTE_PIPELINE_INACTIVE', `Pipeline ${pipelineId} is ${pipeline.status}. Cannot route.`);
  }

  const routeId = crypto.randomUUID();
  const routedAt = Date.now();

  const routeRecord = {
    routeId,
    intentId: intentValidation.intentId,
    nodeId: intentValidation.nodeId,
    action: intentValidation.action,
    pipelineId,
    pipelineName: pipeline.name,
    payload,
    status: 'QUEUED',
    routedAt,
    steps: pipeline.steps.map((step, i) => ({
      sequence: i + 1,
      name: step.name,
      handler: step.handler,
      status: 'PENDING',
      startedAt: null,
      completedAt: null,
      result: null,
    })),
    mechanism: 'AGENTUM',
    version: AGENTUM_VERSION,
  };

  return routeRecord;
}

// ── PIPELINE EXECUTION ────────────────────────────────────────────────────────

/**
 * Executes a routed action through its pipeline steps sequentially.
 * Each step is monitored — failures halt the pipeline and log the breach point.
 *
 * @param {object} routeRecord - From routeAction()
 * @param {object} handlers - { [handlerName]: async function(payload, context) }
 * @returns {object} executionResult
 */
async function executeRoute(routeRecord, handlers = {}) {
  const executionId = crypto.randomUUID();
  const startedAt = Date.now();
  const stepResults = [];
  let finalStatus = 'SUCCESS';
  let haltedAt = null;

  const updatedSteps = [...routeRecord.steps];

  for (let i = 0; i < updatedSteps.length; i++) {
    const step = updatedSteps[i];
    step.startedAt = Date.now();
    step.status = 'RUNNING';

    try {
      const handler = handlers[step.handler];
      if (!handler) {
        // No handler provided — mark as SKIPPED (allows partial execution)
        step.status = 'SKIPPED';
        step.completedAt = Date.now();
        step.result = { skipped: true, reason: 'NO_HANDLER_PROVIDED' };
      } else {
        const result = await handler(routeRecord.payload, {
          routeId: routeRecord.routeId,
          intentId: routeRecord.intentId,
          stepSequence: step.sequence,
          stepName: step.name,
        });
        step.status = 'COMPLETE';
        step.completedAt = Date.now();
        step.result = result || { success: true };
      }
    } catch (err) {
      step.status = 'FAILED';
      step.completedAt = Date.now();
      step.result = { error: err.message, code: err.code || 'STEP_ERROR' };
      finalStatus = 'FAILED';
      haltedAt = step.sequence;
      break; // Halt pipeline on step failure
    }

    stepResults.push({ ...step });
  }

  const completedAt = Date.now();

  // Execution hash — immutable record of this execution
  const execPayload = JSON.stringify({
    executionId,
    routeId: routeRecord.routeId,
    intentId: routeRecord.intentId,
    pipelineId: routeRecord.pipelineId,
    finalStatus,
    startedAt,
    completedAt,
  });

  const executionHash = crypto.createHash(ALGORITHM).update(execPayload).digest(ENCODING);

  return {
    executionId,
    routeId: routeRecord.routeId,
    intentId: routeRecord.intentId,
    nodeId: routeRecord.nodeId,
    action: routeRecord.action,
    pipelineId: routeRecord.pipelineId,
    pipelineName: routeRecord.pipelineName,
    finalStatus,
    haltedAt,
    steps: updatedSteps,
    executionHash,
    startedAt,
    completedAt,
    durationMs: completedAt - startedAt,
    mechanism: 'AGENTUM',
  };
}

// ── RUNTIME STATE MONITORING ──────────────────────────────────────────────────

/**
 * Generates a runtime state snapshot of all registered pipelines
 * and a set of execution records.
 *
 * @param {Array} executionRecords - Array of execution results
 * @returns {object} runtimeState
 */
function getRuntimeState(executionRecords = []) {
  const now = Date.now();
  const pipelines = listPipelines();

  const successCount = executionRecords.filter(e => e.finalStatus === 'SUCCESS').length;
  const failureCount = executionRecords.filter(e => e.finalStatus === 'FAILED').length;
  const skippedCount = executionRecords.filter(e => e.finalStatus === 'SKIPPED').length;

  return {
    snapshotAt: now,
    pipelines: {
      registered: pipelines.length,
      active: pipelines.filter(p => p.status === 'ACTIVE').length,
      inactive: pipelines.filter(p => p.status !== 'ACTIVE').length,
    },
    executions: {
      total: executionRecords.length,
      success: successCount,
      failed: failureCount,
      skipped: skippedCount,
      successRate: executionRecords.length > 0
        ? ((successCount / executionRecords.length) * 100).toFixed(1) + '%'
        : 'N/A',
    },
    mechanism: 'AGENTUM',
    version: AGENTUM_VERSION,
  };
}

// ── CAPABILITY ROUTER ─────────────────────────────────────────────────────────

/**
 * Routes a capability request to the appropriate pipeline based on action type.
 * Maintains a capability map — action → pipelineId.
 */
const _capabilityMap = new Map();

function registerCapability(action, pipelineId) {
  if (!action || !pipelineId) {
    throw new AgentumError('CAPABILITY_INVALID', 'Action and pipelineId are required.');
  }
  _capabilityMap.set(action, pipelineId);
  return { action, pipelineId, registeredAt: Date.now(), mechanism: 'AGENTUM' };
}

function resolveCapability(action) {
  if (!_capabilityMap.has(action)) {
    throw new AgentumError('CAPABILITY_NOT_FOUND', `No pipeline registered for action: ${action}`);
  }
  return _capabilityMap.get(action);
}

// ── PERSISTENCE ───────────────────────────────────────────────────────────────

function persistExecution(executionResult, outputDir = './agentum-store') {
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  const filePath = path.join(outputDir, `${executionResult.executionId}.execution.json`);
  fs.writeFileSync(filePath, JSON.stringify(executionResult, null, 2), 'utf8');
  return filePath;
}

// ── ERROR CLASS ───────────────────────────────────────────────────────────────

class AgentumError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'AgentumError';
    this.code = code;
    this.mechanism = 'AGENTUM';
    this.timestamp = Date.now();
  }
}

// ── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  registerPipeline,
  getPipeline,
  listPipelines,
  routeAction,
  executeRoute,
  getRuntimeState,
  registerCapability,
  resolveCapability,
  persistExecution,
  AgentumError,
  AGENTUM_VERSION,
};
