'use strict';

const {
  registerPipeline,
  routeAction,
  executeRoute,
  getRuntimeState,
  registerCapability,
  resolveCapability,
  persistExecution,
  AgentumError,
} = require('../src/agentum');

console.log('\n══════════════════════════════════════════');
console.log('  AGENTUM™ — Execution & Orchestration Driver');
console.log('  ARCHAI™ Governance Framework');
console.log('  Barkdale & Co.');
console.log('══════════════════════════════════════════\n');

// 1. Register pipelines
console.log('[1] Registering pipelines...');
const pipeline = registerPipeline({
  id: 'pipeline-route-a',
  name: 'Primary Processing Pipeline',
  authority: 'Barkdale & Co.',
  steps: [
    { name: 'Validate Payload', handler: 'validatePayload' },
    { name: 'Transform Data', handler: 'transformData' },
    { name: 'Route to Output', handler: 'routeOutput' },
  ],
});
console.log('    ✓ Pipeline registered:', pipeline.name);
console.log('    Steps:', pipeline.steps.map(s => s.name).join(' → '));

// 2. Register capability mapping
console.log('\n[2] Registering capability map...');
registerCapability('EXECUTE_PIPELINE_ROUTE_A', 'pipeline-route-a');
const resolvedId = resolveCapability('EXECUTE_PIPELINE_ROUTE_A');
console.log('    ✓ Capability resolved:', resolvedId);

// 3. Simulate validated INTENTUM result
const mockIntentValidation = {
  valid: true,
  intentId: 'mock-intent-001',
  nodeId: 'agent-node-001',
  action: 'EXECUTE_PIPELINE_ROUTE_A',
  justification: 'Routing approved batch payload.',
  authority: 'Barkdale & Co.',
  reason: 'INTENT_VALIDATED',
  validatedAt: Date.now(),
  mechanism: 'INTENTUM',
};

// 4. Route action
console.log('\n[3] Routing action through pipeline...');
const routeRecord = routeAction(mockIntentValidation, 'pipeline-route-a', {
  batchId: 'batch-20260621',
  records: 142,
});
console.log('    ✓ Action routed');
console.log('    Route ID:', routeRecord.routeId);
console.log('    Pipeline:', routeRecord.pipelineName);
console.log('    Status  :', routeRecord.status);

// 5. Execute route with handlers
console.log('\n[4] Executing pipeline...');
const handlers = {
  validatePayload: async (payload) => {
    await new Promise(r => setTimeout(r, 10));
    return { validated: true, records: payload.records };
  },
  transformData: async (payload) => {
    await new Promise(r => setTimeout(r, 15));
    return { transformed: true, outputRecords: payload.records };
  },
  routeOutput: async (payload) => {
    await new Promise(r => setTimeout(r, 5));
    return { routed: true, destination: 'output-queue-primary' };
  },
};

executeRoute(routeRecord, handlers).then(result => {
  console.log('    ✓ Execution complete');
  console.log('    Status      :', result.finalStatus);
  console.log('    Duration    :', result.durationMs + 'ms');
  console.log('    Exec Hash   :', result.executionHash.slice(0, 24) + '...');
  result.steps.forEach(s => {
    console.log(`    → [${s.sequence}] ${s.name}: ${s.status}`);
  });

  // 6. Test invalid intent rejection
  console.log('\n[5] Testing invalid intent rejection...');
  try {
    routeAction({ valid: false, reason: 'ACTION_MISMATCH' }, 'pipeline-route-a', {});
    console.log('    ERROR: Should have thrown');
  } catch (e) {
    console.log('    ✓ Invalid intent rejected:', e.code);
  }

  // 7. Runtime state
  console.log('\n[6] Runtime state snapshot...');
  const state = getRuntimeState([result]);
  console.log('    ✓ State captured');
  console.log('    Pipelines registered:', state.pipelines.registered);
  console.log('    Executions total    :', state.executions.total);
  console.log('    Success rate        :', state.executions.successRate);

  // 8. Persist execution
  console.log('\n[7] Persisting execution record...');
  const filePath = persistExecution(result, './agentum-store');
  console.log('    ✓ Persisted to:', filePath);

  console.log('\n══════════════════════════════════════════');
  console.log('  All AGENTUM™ primitives operational.');
  console.log('══════════════════════════════════════════\n');
});
