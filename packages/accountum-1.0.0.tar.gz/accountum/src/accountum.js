'use strict';

/**
 * ACCOUNTUM™ — Accountability Spine Ledger
 * ARCHAI™ Governance Framework · Barkdale & Co.
 * Credential: ARCH-DA-001-2026
 *
 * Monitors cross-referenced, unalterable compliance ledgers tracking all
 * execution steps and data adjustments. Every entry is immutable, chained,
 * and non-repudiable. The trust anchor of the ARCHAI network.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const ACCOUNTUM_VERSION = '1.0.0';
const ALGORITHM = 'sha256';
const ENCODING = 'hex';

// In-memory ledger (persisted to disk)
const _ledger = [];
let _ledgerChainHash = 'GENESIS';

// ── LEDGER ENTRY ──────────────────────────────────────────────────────────────

/**
 * Records an immutable ledger entry for any governed action.
 * Each entry is chained to the previous — tampering breaks the chain.
 *
 * @param {object} anchor - Valid IDENTARCH anchor
 * @param {object} entryDescriptor - { action, outcome, intentId, details }
 * @returns {object} ledgerEntry
 */
function recordEntry(anchor, entryDescriptor) {
  if (!anchor || !anchor.anchorHash) {
    throw new AccountumError('LEDGER_NO_ANCHOR', 'Cannot record entry without a valid IDENTARCH anchor.');
  }

  const { action, outcome, intentId = null, details = {} } = entryDescriptor;

  if (!action) throw new AccountumError('LEDGER_NO_ACTION', 'Action is required for ledger entry.');
  if (!['SUCCESS', 'FAILURE', 'PARTIAL', 'REVOKED'].includes(outcome)) {
    throw new AccountumError('LEDGER_INVALID_OUTCOME', `Outcome must be SUCCESS, FAILURE, PARTIAL, or REVOKED. Got: ${outcome}`);
  }

  const entryId = crypto.randomUUID();
  const recordedAt = Date.now();
  const sequence = _ledger.length + 1;

  // Chain hash — links this entry to the previous
  const chainPayload = JSON.stringify({
    entryId,
    sequence,
    anchorHash: anchor.anchorHash,
    nodeId: anchor.nodeId,
    action,
    outcome,
    intentId,
    recordedAt,
    previousChainHash: _ledgerChainHash,
  });

  const entryHash = crypto.createHash(ALGORITHM).update(chainPayload).digest(ENCODING);

  const entry = {
    entryId,
    sequence,
    nodeId: anchor.nodeId,
    anchorHash: anchor.anchorHash,
    authority: anchor.authority,
    action,
    outcome,
    intentId,
    details,
    entryHash,
    previousChainHash: _ledgerChainHash,
    recordedAt,
    mechanism: 'ACCOUNTUM',
    version: ACCOUNTUM_VERSION,
  };

  // Update chain hash
  _ledgerChainHash = entryHash;
  _ledger.push(entry);

  return entry;
}

// ── CHAIN INTEGRITY VERIFICATION ──────────────────────────────────────────────

/**
 * Verifies the integrity of the entire ledger chain.
 * Any tampering with any entry will break the chain and be detected.
 *
 * @param {Array} entries - Optional external ledger to verify (defaults to internal)
 * @returns {object} integrityReport
 */
function verifyChain(entries = null) {
  const ledgerToVerify = entries || _ledger;
  const verifiedAt = Date.now();

  if (ledgerToVerify.length === 0) {
    return {
      valid: true,
      reason: 'LEDGER_EMPTY',
      entries: 0,
      verifiedAt,
      mechanism: 'ACCOUNTUM',
    };
  }

  let previousChainHash = 'GENESIS';
  const violations = [];

  for (const entry of ledgerToVerify) {
    // Recompute entry hash
    const expectedPayload = JSON.stringify({
      entryId: entry.entryId,
      sequence: entry.sequence,
      anchorHash: entry.anchorHash,
      nodeId: entry.nodeId,
      action: entry.action,
      outcome: entry.outcome,
      intentId: entry.intentId,
      recordedAt: entry.recordedAt,
      previousChainHash: entry.previousChainHash,
    });

    const expectedHash = crypto.createHash(ALGORITHM).update(expectedPayload).digest(ENCODING);

    if (expectedHash !== entry.entryHash) {
      violations.push({
        sequence: entry.sequence,
        entryId: entry.entryId,
        violation: 'ENTRY_HASH_TAMPERED',
      });
    }

    if (entry.previousChainHash !== previousChainHash) {
      violations.push({
        sequence: entry.sequence,
        entryId: entry.entryId,
        violation: 'CHAIN_LINK_BROKEN',
      });
    }

    previousChainHash = entry.entryHash;
  }

  return {
    valid: violations.length === 0,
    entries: ledgerToVerify.length,
    violations: violations.length,
    violationDetails: violations,
    currentChainHash: previousChainHash,
    reason: violations.length === 0 ? 'CHAIN_INTACT' : 'CHAIN_COMPROMISED',
    verifiedAt,
    mechanism: 'ACCOUNTUM',
  };
}

// ── COMPLIANCE QUERY ──────────────────────────────────────────────────────────

/**
 * Queries the ledger for compliance reporting.
 * Supports filtering by nodeId, action, outcome, and time range.
 *
 * @param {object} filters - { nodeId, action, outcome, fromMs, toMs }
 * @returns {object} complianceReport
 */
function queryLedger(filters = {}) {
  const { nodeId, action, outcome, fromMs, toMs } = filters;
  const now = Date.now();

  let results = [..._ledger];

  if (nodeId) results = results.filter(e => e.nodeId === nodeId);
  if (action) results = results.filter(e => e.action === action);
  if (outcome) results = results.filter(e => e.outcome === outcome);
  if (fromMs) results = results.filter(e => e.recordedAt >= fromMs);
  if (toMs) results = results.filter(e => e.recordedAt <= toMs);

  const successCount = results.filter(e => e.outcome === 'SUCCESS').length;
  const failureCount = results.filter(e => e.outcome === 'FAILURE').length;

  return {
    queriedAt: now,
    totalLedgerEntries: _ledger.length,
    matchedEntries: results.length,
    filters,
    summary: {
      success: successCount,
      failure: failureCount,
      partial: results.filter(e => e.outcome === 'PARTIAL').length,
      revoked: results.filter(e => e.outcome === 'REVOKED').length,
      complianceRate: results.length > 0
        ? ((successCount / results.length) * 100).toFixed(1) + '%'
        : 'N/A',
    },
    entries: results,
    mechanism: 'ACCOUNTUM',
  };
}

// ── WEBHOOK REGULATION ────────────────────────────────────────────────────────

/**
 * Evaluates ledger entries against compliance thresholds.
 * Returns a webhook-ready alert payload if thresholds are breached.
 *
 * @param {object} thresholds - { maxFailureRate, maxConsecutiveFailures }
 * @returns {object} webhookPayload or null
 */
function evaluateCompliance(thresholds = {}) {
  const { maxFailureRate = 0.2, maxConsecutiveFailures = 3 } = thresholds;
  const now = Date.now();

  if (_ledger.length === 0) return null;

  const failureCount = _ledger.filter(e => e.outcome === 'FAILURE').length;
  const failureRate = failureCount / _ledger.length;

  // Count consecutive failures at end of ledger
  let consecutiveFailures = 0;
  for (let i = _ledger.length - 1; i >= 0; i--) {
    if (_ledger[i].outcome === 'FAILURE') consecutiveFailures++;
    else break;
  }

  const breaches = [];
  if (failureRate > maxFailureRate) {
    breaches.push({ type: 'FAILURE_RATE_EXCEEDED', value: failureRate.toFixed(3), threshold: maxFailureRate });
  }
  if (consecutiveFailures >= maxConsecutiveFailures) {
    breaches.push({ type: 'CONSECUTIVE_FAILURES', value: consecutiveFailures, threshold: maxConsecutiveFailures });
  }

  if (breaches.length === 0) return null;

  return {
    alert: true,
    severity: consecutiveFailures >= maxConsecutiveFailures ? 'CRITICAL' : 'WARNING',
    breaches,
    ledgerEntries: _ledger.length,
    evaluatedAt: now,
    mechanism: 'ACCOUNTUM',
  };
}

// ── STATE REVOCATION ──────────────────────────────────────────────────────────

/**
 * Records a state revocation entry — marks a prior action as revoked
 * with a reference back to the original entry.
 */
function recordRevocation(anchor, originalEntryId, reason) {
  const originalEntry = _ledger.find(e => e.entryId === originalEntryId);
  if (!originalEntry) {
    throw new AccountumError('REVOKE_ENTRY_NOT_FOUND', `No ledger entry found for id: ${originalEntryId}`);
  }

  return recordEntry(anchor, {
    action: `REVOKE:${originalEntry.action}`,
    outcome: 'REVOKED',
    intentId: originalEntry.intentId,
    details: { originalEntryId, revocationReason: reason, originalAction: originalEntry.action },
  });
}

// ── PERSISTENCE ───────────────────────────────────────────────────────────────

function persistLedger(outputDir = './accountum-store') {
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  const filePath = path.join(outputDir, `ledger-${Date.now()}.json`);
  fs.writeFileSync(filePath, JSON.stringify({
    exportedAt: Date.now(),
    entryCount: _ledger.length,
    chainHash: _ledgerChainHash,
    entries: _ledger,
  }, null, 2), 'utf8');
  return filePath;
}

function getLedger() { return [..._ledger]; }
function getChainHash() { return _ledgerChainHash; }

// ── ERROR CLASS ───────────────────────────────────────────────────────────────

class AccountumError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'AccountumError';
    this.code = code;
    this.mechanism = 'ACCOUNTUM';
    this.timestamp = Date.now();
  }
}

// ── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  recordEntry,
  verifyChain,
  queryLedger,
  evaluateCompliance,
  recordRevocation,
  persistLedger,
  getLedger,
  getChainHash,
  AccountumError,
  ACCOUNTUM_VERSION,
};
