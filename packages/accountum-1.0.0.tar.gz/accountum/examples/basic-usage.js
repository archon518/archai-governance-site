'use strict';

const crypto = require('crypto');
const {
  recordEntry,
  verifyChain,
  queryLedger,
  evaluateCompliance,
  recordRevocation,
  persistLedger,
  getLedger,
} = require('../src/accountum');

console.log('\n══════════════════════════════════════════');
console.log('  ACCOUNTUM™ — Accountability Spine Ledger');
console.log('  ARCHAI™ Governance Framework');
console.log('  Barkdale & Co.');
console.log('══════════════════════════════════════════\n');

const now = Date.now();
const mockAnchor = {
  nodeId: 'agent-node-001', role: 'EXECUTION_AGENT',
  authority: 'Barkdale & Co.',
  anchorHash: crypto.createHash('sha256').update('mock-anchor-001').digest('hex'),
  issuedAt: now, expiresAt: now + 86400000, mechanism: 'IDENTARCH',
};

console.log('[1] Recording ledger entries...');
const entry1 = recordEntry(mockAnchor, {
  action: 'EXECUTE_PIPELINE_ROUTE_A', outcome: 'SUCCESS',
  intentId: 'mock-intent-001', details: { records: 142 },
});
const entry2 = recordEntry(mockAnchor, {
  action: 'EXECUTE_PIPELINE_ROUTE_B', outcome: 'SUCCESS',
  intentId: 'mock-intent-002', details: { records: 87 },
});
const entry3 = recordEntry(mockAnchor, {
  action: 'WRITE_MEMORY_RECORD', outcome: 'SUCCESS',
  intentId: 'mock-intent-003', details: { schemaId: 'execution-log-schema' },
});
console.log('    ✓ 3 entries recorded');
console.log('    Entry 1 hash:', entry1.entryHash.slice(0, 24) + '...');
console.log('    Entry 2 prev:', entry2.previousChainHash.slice(0, 24) + '...');
console.log('    Chain linked :', entry2.previousChainHash === entry1.entryHash ? 'YES' : 'NO');

console.log('\n[2] Verifying chain integrity...');
const integrity = verifyChain();
console.log('    ✓ Chain valid:', integrity.valid);
console.log('    Entries      :', integrity.entries);
console.log('    Violations   :', integrity.violations);
console.log('    Reason       :', integrity.reason);

console.log('\n[3] Testing tamper detection...');
const ledgerCopy = getLedger();
const tampered = ledgerCopy.map((e, i) =>
  i === 1 ? { ...e, outcome: 'FAILURE' } : e
);
const tamperedCheck = verifyChain(tampered);
console.log('    ✓ Tampered chain detected:', !tamperedCheck.valid ? 'YES (CORRECT)' : 'NO (ERROR)');
console.log('    Violations   :', tamperedCheck.violations);

console.log('\n[4] Querying ledger...');
const report = queryLedger({ outcome: 'SUCCESS' });
console.log('    ✓ Query complete');
console.log('    Total entries :', report.totalLedgerEntries);
console.log('    Matched       :', report.matchedEntries);
console.log('    Compliance    :', report.summary.complianceRate);

console.log('\n[5] Recording revocation...');
const revocation = recordRevocation(mockAnchor, entry2.entryId, 'OPERATOR_OVERRIDE');
console.log('    ✓ Revocation recorded');
console.log('    Sequence      :', revocation.sequence);
console.log('    Action        :', revocation.action);

console.log('\n[6] Compliance evaluation...');
const webhook = evaluateCompliance({ maxFailureRate: 0.5, maxConsecutiveFailures: 3 });
console.log('    ✓ Compliance evaluated');
console.log('    Alert triggered:', webhook ? 'YES' : 'NO (all within thresholds)');

console.log('\n[7] Persisting ledger...');
const filePath = persistLedger('./accountum-store');
console.log('    ✓ Ledger persisted to:', filePath);

console.log('\n══════════════════════════════════════════');
console.log('  All ACCOUNTUM™ primitives operational.');
console.log('══════════════════════════════════════════\n');
