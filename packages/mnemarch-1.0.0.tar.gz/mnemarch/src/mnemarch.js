'use strict';

/**
 * MNEMARCH™ — Memory Governance Subsystem
 * ARCHAI™ Governance Framework · Barkdale & Co.
 * Credential: ARCH-DA-001-2026
 *
 * Manages database storage schema execution, strict file attribution patterns,
 * and temporal data decay windows. Enforces strict boundaries on what is
 * retained, by whom, and for how long. All stored data must be attributed
 * to a verified node anchor.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const MNEMARCH_VERSION = '1.0.0';
const ALGORITHM = 'sha256';
const ENCODING = 'hex';
const DEFAULT_DECAY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

// ── MEMORY SCHEMA ─────────────────────────────────────────────────────────────

const _schemas = new Map();

function registerSchema(schemaDescriptor) {
  const { id, name, fields, retentionMs, authority } = schemaDescriptor;
  if (!id || !name || !Array.isArray(fields)) {
    throw new MnemarchError('SCHEMA_INVALID', 'Schema requires id, name, and fields array.');
  }
  const schema = {
    id, name, fields,
    retentionMs: retentionMs || DEFAULT_DECAY_MS,
    authority: authority || 'Barkdale & Co.',
    registeredAt: Date.now(),
    mechanism: 'MNEMARCH',
  };
  _schemas.set(id, schema);
  return schema;
}

function getSchema(schemaId) {
  if (!_schemas.has(schemaId)) {
    throw new MnemarchError('SCHEMA_NOT_FOUND', `No schema registered with id: ${schemaId}`);
  }
  return _schemas.get(schemaId);
}

// ── ATTRIBUTED WRITE ──────────────────────────────────────────────────────────

/**
 * Writes a memory record with full attribution to a node anchor.
 * Every write is time-stamped, schema-validated, and decay-scheduled.
 *
 * @param {object} anchor - Valid IDENTARCH anchor
 * @param {string} schemaId - Registered schema ID
 * @param {object} data - Data to store
 * @returns {object} memoryRecord
 */
function writeMemory(anchor, schemaId, data) {
  if (!anchor || !anchor.anchorHash) {
    throw new MnemarchError('WRITE_NO_ANCHOR', 'Cannot write memory without a valid IDENTARCH anchor.');
  }

  const now = Date.now();
  if (now > anchor.expiresAt) {
    throw new MnemarchError('WRITE_ANCHOR_EXPIRED', `Anchor for node ${anchor.nodeId} has expired.`);
  }

  const schema = getSchema(schemaId);

  // Validate fields against schema
  const missingFields = schema.fields
    .filter(f => f.required && !(f.name in data));
  if (missingFields.length > 0) {
    throw new MnemarchError(
      'WRITE_SCHEMA_VIOLATION',
      `Missing required fields: ${missingFields.map(f => f.name).join(', ')}`
    );
  }

  const memoryId = crypto.randomUUID();
  const decayAt = now + schema.retentionMs;

  // Attribution hash — binds this record to the writing node
  const attributionPayload = JSON.stringify({
    memoryId,
    anchorHash: anchor.anchorHash,
    nodeId: anchor.nodeId,
    schemaId,
    writtenAt: now,
  });

  const attributionHash = crypto
    .createHash(ALGORITHM)
    .update(attributionPayload)
    .digest(ENCODING);

  return {
    memoryId,
    nodeId: anchor.nodeId,
    anchorHash: anchor.anchorHash,
    authority: anchor.authority,
    schemaId,
    schemaName: schema.name,
    data,
    attributionHash,
    writtenAt: now,
    decayAt,
    status: 'ACTIVE',
    mechanism: 'MNEMARCH',
    version: MNEMARCH_VERSION,
  };
}

// ── TEMPORAL DECAY ────────────────────────────────────────────────────────────

/**
 * Evaluates a set of memory records and marks expired ones for decay.
 * Returns a decay report with records to purge and records still active.
 *
 * @param {Array} memoryRecords
 * @returns {object} decayReport
 */
function evaluateDecay(memoryRecords) {
  const now = Date.now();
  const active = [];
  const decayed = [];

  for (const record of memoryRecords) {
    if (now >= record.decayAt) {
      decayed.push({ ...record, status: 'DECAYED', decayedAt: now });
    } else {
      const remainingMs = record.decayAt - now;
      active.push({ ...record, remainingMs });
    }
  }

  return {
    evaluatedAt: now,
    total: memoryRecords.length,
    active: active.length,
    decayed: decayed.length,
    activeRecords: active,
    decayedRecords: decayed,
    mechanism: 'MNEMARCH',
  };
}

/**
 * Purges decayed records from a store directory.
 * @param {string} storeDir
 * @returns {object} purgeReport
 */
function purgeDecayed(storeDir = './mnemarch-store') {
  if (!fs.existsSync(storeDir)) return { purged: 0, storeDir };
  const now = Date.now();
  const files = fs.readdirSync(storeDir).filter(f => f.endsWith('.memory.json'));
  let purged = 0;

  for (const file of files) {
    const filePath = path.join(storeDir, file);
    try {
      const record = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (now >= record.decayAt) {
        fs.unlinkSync(filePath);
        purged++;
      }
    } catch {
      // Skip unreadable files
    }
  }

  return { purged, remaining: files.length - purged, purgedAt: now, mechanism: 'MNEMARCH' };
}

// ── ACCESS CONTROL ────────────────────────────────────────────────────────────

/**
 * Checks whether a node anchor is authorized to read a memory record.
 * Authorization is based on matching authority and node role.
 *
 * @param {object} anchor - Requesting node's anchor
 * @param {object} memoryRecord - The record being accessed
 * @param {Array} allowedRoles - Roles permitted to read
 * @returns {object} accessResult
 */
function checkAccess(anchor, memoryRecord, allowedRoles = []) {
  const checkedAt = Date.now();

  if (!anchor || !anchor.anchorHash) {
    return { granted: false, reason: 'ACCESS_NO_ANCHOR', checkedAt, mechanism: 'MNEMARCH' };
  }

  if (checkedAt > anchor.expiresAt) {
    return { granted: false, reason: 'ACCESS_ANCHOR_EXPIRED', checkedAt, mechanism: 'MNEMARCH' };
  }

  if (memoryRecord.status === 'DECAYED') {
    return { granted: false, reason: 'ACCESS_RECORD_DECAYED', checkedAt, mechanism: 'MNEMARCH' };
  }

  // Owner always has access
  if (anchor.nodeId === memoryRecord.nodeId) {
    return { granted: true, reason: 'ACCESS_OWNER', checkedAt, mechanism: 'MNEMARCH' };
  }

  // Role-based access
  if (allowedRoles.length > 0 && allowedRoles.includes(anchor.role)) {
    return { granted: true, reason: 'ACCESS_ROLE_PERMITTED', checkedAt, mechanism: 'MNEMARCH' };
  }

  return { granted: false, reason: 'ACCESS_DENIED', checkedAt, mechanism: 'MNEMARCH' };
}

// ── PERSISTENCE ───────────────────────────────────────────────────────────────

function persistMemory(memoryRecord, outputDir = './mnemarch-store') {
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  const filePath = path.join(outputDir, `${memoryRecord.memoryId}.memory.json`);
  fs.writeFileSync(filePath, JSON.stringify(memoryRecord, null, 2), 'utf8');
  return filePath;
}

function loadMemory(memoryId, storeDir = './mnemarch-store') {
  const filePath = path.join(storeDir, `${memoryId}.memory.json`);
  if (!fs.existsSync(filePath)) {
    throw new MnemarchError('MEMORY_NOT_FOUND', `No memory record found for id: ${memoryId}`);
  }
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

// ── ERROR CLASS ───────────────────────────────────────────────────────────────

class MnemarchError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'MnemarchError';
    this.code = code;
    this.mechanism = 'MNEMARCH';
    this.timestamp = Date.now();
  }
}

// ── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  registerSchema,
  getSchema,
  writeMemory,
  evaluateDecay,
  purgeDecayed,
  checkAccess,
  persistMemory,
  loadMemory,
  MnemarchError,
  MNEMARCH_VERSION,
};
