'use strict';

const crypto = require('crypto');
const {
  registerSchema,
  writeMemory,
  evaluateDecay,
  checkAccess,
  persistMemory,
  loadMemory,
} = require('../src/mnemarch');

console.log('\n══════════════════════════════════════════');
console.log('  MNEMARCH™ — Memory Governance Subsystem');
console.log('  ARCHAI™ Governance Framework');
console.log('  Barkdale & Co.');
console.log('══════════════════════════════════════════\n');

const now = Date.now();
const mockAnchor = {
  nodeId: 'agent-node-001', role: 'EXECUTION_AGENT',
  authority: 'Barkdale & Co.',
  anchorHash: crypto.createHash('sha256').update('mock-anchor-001').digest('hex'),
  issuedAt: now, expiresAt: now + 86400000, mechanism: 'IDENTARCH',
};

console.log('[1] Registering memory schema...');
const schema = registerSchema({
  id: 'execution-log-schema',
  name: 'Execution Log',
  retentionMs: 7 * 24 * 60 * 60 * 1000,
  fields: [
    { name: 'action', required: true },
    { name: 'result', required: true },
    { name: 'duration', required: false },
  ],
});
console.log('    ✓ Schema registered:', schema.name);
console.log('    Retention:', (schema.retentionMs / 86400000).toFixed(0) + ' days');

console.log('\n[2] Writing attributed memory record...');
const record = writeMemory(mockAnchor, 'execution-log-schema', {
  action: 'EXECUTE_PIPELINE_ROUTE_A',
  result: 'SUCCESS',
  duration: 32,
});
console.log('    ✓ Memory written');
console.log('    Memory ID       :', record.memoryId);
console.log('    Attribution Hash:', record.attributionHash.slice(0, 24) + '...');
console.log('    Decay at        :', new Date(record.decayAt).toISOString());

console.log('\n[3] Evaluating decay...');
const decayReport = evaluateDecay([record]);
console.log('    ✓ Decay evaluated');
console.log('    Active  :', decayReport.active);
console.log('    Decayed :', decayReport.decayed);
console.log('    Remaining:', Math.floor(decayReport.activeRecords[0].remainingMs / 3600000) + ' hours');

console.log('\n[4] Checking access control...');
const ownerAccess = checkAccess(mockAnchor, record, []);
console.log('    ✓ Owner access:', ownerAccess.granted ? 'GRANTED' : 'DENIED', '—', ownerAccess.reason);

const foreignAnchor = { ...mockAnchor, nodeId: 'foreign-node-999', role: 'POLICY_ENFORCER', expiresAt: now + 86400000 };
const roleAccess = checkAccess(foreignAnchor, record, ['POLICY_ENFORCER']);
console.log('    ✓ Role access  :', roleAccess.granted ? 'GRANTED' : 'DENIED', '—', roleAccess.reason);

const deniedAccess = checkAccess(foreignAnchor, record, []);
console.log('    ✓ Denied access:', deniedAccess.granted ? 'GRANTED (ERROR)' : 'DENIED (CORRECT)', '—', deniedAccess.reason);

console.log('\n[5] Persisting memory record...');
const filePath = persistMemory(record, './mnemarch-store');
console.log('    ✓ Persisted to:', filePath);
const reloaded = loadMemory(record.memoryId, './mnemarch-store');
console.log('    ✓ Reloaded attribution matches:', reloaded.attributionHash === record.attributionHash);

console.log('\n══════════════════════════════════════════');
console.log('  All MNEMARCH™ primitives operational.');
console.log('══════════════════════════════════════════\n');
