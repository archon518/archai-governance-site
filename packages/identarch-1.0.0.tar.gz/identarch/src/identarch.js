'use strict';

/**
 * IDENTARCH™ — Identity Substrate Engine
 * ARCHAI™ Governance Framework · Barkdale & Co.
 * Credential: ARCH-DA-001-2026
 *
 * Establishes foundational identity primitives for all ARCHAI layers.
 * Binds running nodes to verifiable, cryptographically anchored claims.
 * No downstream mechanism may operate without a valid IDENTARCH binding.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ── CONSTANTS ────────────────────────────────────────────────────────────────

const IDENTARCH_VERSION = '1.0.0';
const ALGORITHM = 'sha256';
const ENCODING = 'hex';
const CLAIM_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours default

// ── IDENTITY ANCHOR ───────────────────────────────────────────────────────────

/**
 * Generates a cryptographic identity anchor for a node.
 * The anchor is the root claim — all subsequent verification chains from this.
 *
 * @param {object} nodeDescriptor - { id, role, authority, metadata }
 * @returns {object} anchor — { nodeId, anchorHash, issuedAt, expiresAt, authority }
 */
function generateAnchor(nodeDescriptor) {
  const { id, role, authority, metadata = {} } = nodeDescriptor;

  if (!id || !role || !authority) {
    throw new IdentarchError('ANCHOR_INVALID_DESCRIPTOR', 'Node descriptor requires id, role, and authority.');
  }

  const issuedAt = Date.now();
  const expiresAt = issuedAt + (metadata.expiryMs || CLAIM_EXPIRY_MS);

  const anchorPayload = JSON.stringify({
    nodeId: id,
    role,
    authority,
    issuedAt,
    expiresAt,
    metadata,
    version: IDENTARCH_VERSION,
  });

  const anchorHash = crypto
    .createHash(ALGORITHM)
    .update(anchorPayload)
    .digest(ENCODING);

  return {
    nodeId: id,
    role,
    authority,
    anchorHash,
    issuedAt,
    expiresAt,
    metadata,
    version: IDENTARCH_VERSION,
    mechanism: 'IDENTARCH',
  };
}

// ── VERIFICATION CLAIM ────────────────────────────────────────────────────────

/**
 * Issues a verification claim against an existing anchor.
 * Claims are lightweight signed tokens used per-operation.
 *
 * @param {object} anchor - A valid anchor from generateAnchor()
 * @param {string} operationContext - Description of the operation being claimed
 * @returns {object} claim — { claimId, anchorHash, operationContext, claimHash, issuedAt }
 */
function issueClaim(anchor, operationContext) {
  if (!anchor || !anchor.anchorHash) {
    throw new IdentarchError('CLAIM_NO_ANCHOR', 'Cannot issue claim without a valid anchor.');
  }

  if (!operationContext || typeof operationContext !== 'string') {
    throw new IdentarchError('CLAIM_NO_CONTEXT', 'Operation context is required to issue a claim.');
  }

  const now = Date.now();

  if (now > anchor.expiresAt) {
    throw new IdentarchError('CLAIM_ANCHOR_EXPIRED', `Anchor expired at ${new Date(anchor.expiresAt).toISOString()}.`);
  }

  const claimId = crypto.randomUUID();

  const claimPayload = JSON.stringify({
    claimId,
    anchorHash: anchor.anchorHash,
    nodeId: anchor.nodeId,
    operationContext,
    issuedAt: now,
  });

  const claimHash = crypto
    .createHash(ALGORITHM)
    .update(claimPayload)
    .digest(ENCODING);

  return {
    claimId,
    nodeId: anchor.nodeId,
    anchorHash: anchor.anchorHash,
    operationContext,
    claimHash,
    issuedAt: now,
    mechanism: 'IDENTARCH',
  };
}

// ── VERIFICATION ──────────────────────────────────────────────────────────────

/**
 * Verifies a claim against its source anchor.
 * Returns a verification result with pass/fail and reason.
 *
 * @param {object} claim - A claim from issueClaim()
 * @param {object} anchor - The anchor the claim was issued against
 * @returns {object} result — { verified, nodeId, claimId, reason, verifiedAt }
 */
function verifyClaim(claim, anchor) {
  const verifiedAt = Date.now();

  if (!claim || !anchor) {
    return _failResult(null, null, 'MISSING_INPUTS', verifiedAt);
  }

  // Anchor hash must match
  if (claim.anchorHash !== anchor.anchorHash) {
    return _failResult(claim.claimId, claim.nodeId, 'ANCHOR_HASH_MISMATCH', verifiedAt);
  }

  // Node IDs must match
  if (claim.nodeId !== anchor.nodeId) {
    return _failResult(claim.claimId, claim.nodeId, 'NODE_ID_MISMATCH', verifiedAt);
  }

  // Anchor must not be expired at time of claim issuance
  if (claim.issuedAt > anchor.expiresAt) {
    return _failResult(claim.claimId, claim.nodeId, 'CLAIM_ISSUED_AFTER_ANCHOR_EXPIRY', verifiedAt);
  }

  // Recompute claim hash to detect tampering
  const expectedPayload = JSON.stringify({
    claimId: claim.claimId,
    anchorHash: claim.anchorHash,
    nodeId: claim.nodeId,
    operationContext: claim.operationContext,
    issuedAt: claim.issuedAt,
  });

  const expectedHash = crypto
    .createHash(ALGORITHM)
    .update(expectedPayload)
    .digest(ENCODING);

  if (expectedHash !== claim.claimHash) {
    return _failResult(claim.claimId, claim.nodeId, 'CLAIM_HASH_TAMPERED', verifiedAt);
  }

  return {
    verified: true,
    claimId: claim.claimId,
    nodeId: claim.nodeId,
    operationContext: claim.operationContext,
    authority: anchor.authority,
    reason: 'CLAIM_VERIFIED',
    verifiedAt,
    mechanism: 'IDENTARCH',
  };
}

// ── CONTEXT ARCHITECTURE MAP ──────────────────────────────────────────────────

/**
 * Builds a context architecture map from multiple anchors.
 * Used by downstream mechanisms (AGENTUM, MNEMARCH) to understand
 * the identity topology of a running system.
 *
 * @param {Array} anchors - Array of valid anchors
 * @returns {object} contextMap — keyed by nodeId
 */
function buildContextMap(anchors) {
  if (!Array.isArray(anchors) || anchors.length === 0) {
    throw new IdentarchError('CONTEXT_MAP_EMPTY', 'At least one anchor is required to build a context map.');
  }

  const now = Date.now();
  const contextMap = {
    generatedAt: now,
    mechanism: 'IDENTARCH',
    version: IDENTARCH_VERSION,
    nodes: {},
  };

  for (const anchor of anchors) {
    const status = now > anchor.expiresAt ? 'EXPIRED' : 'ACTIVE';
    contextMap.nodes[anchor.nodeId] = {
      nodeId: anchor.nodeId,
      role: anchor.role,
      authority: anchor.authority,
      anchorHash: anchor.anchorHash,
      status,
      issuedAt: anchor.issuedAt,
      expiresAt: anchor.expiresAt,
    };
  }

  return contextMap;
}

// ── PERSISTENCE ───────────────────────────────────────────────────────────────

/**
 * Persists an anchor to disk for cross-session reuse.
 * @param {object} anchor
 * @param {string} outputDir
 */
function persistAnchor(anchor, outputDir = './identarch-store') {
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  const filePath = path.join(outputDir, `${anchor.nodeId}.anchor.json`);
  fs.writeFileSync(filePath, JSON.stringify(anchor, null, 2), 'utf8');
  return filePath;
}

/**
 * Loads a persisted anchor from disk.
 * @param {string} nodeId
 * @param {string} storeDir
 */
function loadAnchor(nodeId, storeDir = './identarch-store') {
  const filePath = path.join(storeDir, `${nodeId}.anchor.json`);
  if (!fs.existsSync(filePath)) {
    throw new IdentarchError('ANCHOR_NOT_FOUND', `No persisted anchor found for node: ${nodeId}`);
  }
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

// ── ERROR CLASS ───────────────────────────────────────────────────────────────

class IdentarchError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'IdentarchError';
    this.code = code;
    this.mechanism = 'IDENTARCH';
    this.timestamp = Date.now();
  }
}

// ── INTERNAL HELPERS ──────────────────────────────────────────────────────────

function _failResult(claimId, nodeId, reason, verifiedAt) {
  return {
    verified: false,
    claimId,
    nodeId,
    reason,
    verifiedAt,
    mechanism: 'IDENTARCH',
  };
}

// ── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  generateAnchor,
  issueClaim,
  verifyClaim,
  buildContextMap,
  persistAnchor,
  loadAnchor,
  IdentarchError,
  IDENTARCH_VERSION,
};
