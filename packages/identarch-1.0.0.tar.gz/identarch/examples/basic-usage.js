'use strict';

/**
 * IDENTARCH™ — Basic Usage Example
 * Demonstrates: anchor generation, claim issuance, verification, context mapping
 */

const {
  generateAnchor,
  issueClaim,
  verifyClaim,
  buildContextMap,
  persistAnchor,
  loadAnchor,
  IdentarchError,
} = require('../src/identarch');

console.log('\n══════════════════════════════════════════');
console.log('  IDENTARCH™ — Identity Substrate Engine');
console.log('  ARCHAI™ Governance Framework');
console.log('  Barkdale & Co.');
console.log('══════════════════════════════════════════\n');

// 1. Generate an identity anchor for a node
console.log('[1] Generating identity anchor...');
const anchor = generateAnchor({
  id: 'agent-node-001',
  role: 'EXECUTION_AGENT',
  authority: 'Barkdale & Co.',
  metadata: { environment: 'production', tier: 'control-ring' },
});
console.log('    ✓ Anchor generated');
console.log('    Node ID    :', anchor.nodeId);
console.log('    Anchor Hash:', anchor.anchorHash.slice(0, 24) + '...');
console.log('    Expires    :', new Date(anchor.expiresAt).toISOString());

// 2. Issue a verification claim for an operation
console.log('\n[2] Issuing verification claim...');
const claim = issueClaim(anchor, 'EXECUTE_PIPELINE_ROUTE_A');
console.log('    ✓ Claim issued');
console.log('    Claim ID   :', claim.claimId);
console.log('    Context    :', claim.operationContext);
console.log('    Claim Hash :', claim.claimHash.slice(0, 24) + '...');

// 3. Verify the claim
console.log('\n[3] Verifying claim...');
const result = verifyClaim(claim, anchor);
console.log('    ✓ Verification result:', result.verified ? 'PASS' : 'FAIL');
console.log('    Reason     :', result.reason);
console.log('    Authority  :', result.authority);

// 4. Attempt tamper detection
console.log('\n[4] Testing tamper detection...');
const tamperedClaim = { ...claim, operationContext: 'EXECUTE_UNAUTHORIZED_ROUTE' };
const tamperedResult = verifyClaim(tamperedClaim, anchor);
console.log('    ✓ Tampered claim result:', tamperedResult.verified ? 'PASS (ERROR)' : 'FAIL (CORRECT)');
console.log('    Reason     :', tamperedResult.reason);

// 5. Build context architecture map
console.log('\n[5] Building context architecture map...');
const anchor2 = generateAnchor({
  id: 'memory-node-001',
  role: 'MEMORY_GOVERNANCE',
  authority: 'Barkdale & Co.',
});
const contextMap = buildContextMap([anchor, anchor2]);
console.log('    ✓ Context map built');
console.log('    Nodes registered:', Object.keys(contextMap.nodes).length);
Object.values(contextMap.nodes).forEach(n => {
  console.log(`    → ${n.nodeId} [${n.role}] — ${n.status}`);
});

// 6. Persist and reload anchor
console.log('\n[6] Persisting anchor to disk...');
const filePath = persistAnchor(anchor, './identarch-store');
console.log('    ✓ Persisted to:', filePath);
const reloaded = loadAnchor('agent-node-001', './identarch-store');
console.log('    ✓ Reloaded anchor hash matches:', reloaded.anchorHash === anchor.anchorHash);

console.log('\n══════════════════════════════════════════');
console.log('  All IDENTARCH™ primitives operational.');
console.log('══════════════════════════════════════════\n');
