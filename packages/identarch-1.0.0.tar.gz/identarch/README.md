# IDENTARCH™
## Identity Substrate Engine
### ARCHAI™ Governance Framework — Barkdale & Co.

---

**Credential:** ARCH-DA-001-2026  
**Authority:** Starr Kennelly, Discipline Architect  
**Contact:** anastrophon@barkdale.co  
**Version:** 1.0.0

---

## What IDENTARCH Does

IDENTARCH is the root identity layer of the ARCHAI™ governance stack. Every downstream mechanism — INTENTUM, AGENTUM, MNEMARCH, ACCOUNTUM, POLICUM — requires a valid IDENTARCH binding before it can operate.

It establishes three primitives:

1. **Identity Anchor** — A cryptographic root claim bound to a node descriptor (id, role, authority). All verification chains from this.
2. **Verification Claim** — A lightweight signed token issued per-operation against an anchor.
3. **Context Architecture Map** — A topology map of all registered node identities in a running system.

No operation in a governed ARCHAI system proceeds without a verified claim traceable to a valid anchor.

---

## Requirements

- Node.js >= 18.0.0
- No external dependencies (uses Node built-ins only)

---

## Installation

```bash
tar -xzf identarch-1.0.0.tar.gz
cd identarch
node examples/basic-usage.js
```

---

## Quick Start

```javascript
const { generateAnchor, issueClaim, verifyClaim } = require('./src/identarch');

// 1. Generate an identity anchor for your node
const anchor = generateAnchor({
  id: 'agent-node-001',
  role: 'EXECUTION_AGENT',
  authority: 'Your Organization',
});

// 2. Issue a claim before any operation
const claim = issueClaim(anchor, 'EXECUTE_PIPELINE_ROUTE_A');

// 3. Verify the claim — tampered claims will fail
const result = verifyClaim(claim, anchor);
console.log(result.verified); // true
```

---

## API Reference

### `generateAnchor(nodeDescriptor)`
Generates a cryptographic identity anchor.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | ✓ | Unique node identifier |
| `role` | string | ✓ | Node role (see config/defaults.json) |
| `authority` | string | ✓ | Governing authority name |
| `metadata` | object | — | Optional. `{ expiryMs, environment, tier }` |

Returns: `{ nodeId, role, authority, anchorHash, issuedAt, expiresAt, version, mechanism }`

---

### `issueClaim(anchor, operationContext)`
Issues a verification claim against an anchor.

| Param | Type | Description |
|-------|------|-------------|
| `anchor` | object | Valid anchor from `generateAnchor()` |
| `operationContext` | string | Description of the operation being authorized |

Returns: `{ claimId, nodeId, anchorHash, operationContext, claimHash, issuedAt, mechanism }`

---

### `verifyClaim(claim, anchor)`
Verifies a claim. Detects tampering, expiry, and hash mismatches.

Returns: `{ verified, claimId, nodeId, reason, verifiedAt, mechanism }`

---

### `buildContextMap(anchors[])`
Builds a topology map of all registered node identities.

Returns: `{ generatedAt, nodes: { [nodeId]: { role, authority, status, ... } } }`

---

### `persistAnchor(anchor, outputDir?)`
Writes an anchor to disk as JSON for cross-session reuse.

### `loadAnchor(nodeId, storeDir?)`
Loads a persisted anchor from disk.

---

## Error Codes

| Code | Meaning |
|------|---------|
| `ANCHOR_INVALID_DESCRIPTOR` | Missing id, role, or authority |
| `CLAIM_NO_ANCHOR` | No valid anchor provided |
| `CLAIM_NO_CONTEXT` | No operation context provided |
| `CLAIM_ANCHOR_EXPIRED` | Anchor has passed its expiry |
| `CLAIM_HASH_TAMPERED` | Claim hash does not match recomputed value |
| `ANCHOR_HASH_MISMATCH` | Claim anchor hash doesn't match provided anchor |
| `NODE_ID_MISMATCH` | Claim node ID doesn't match anchor |
| `ANCHOR_NOT_FOUND` | No persisted anchor file found |

---

## Integration with ARCHAI Stack

IDENTARCH is Layer 0. Other mechanisms consume it as follows:

- **INTENTUM™** — Requires an anchor before binding intent records
- **AGENTUM™** — Validates node identity before routing actions
- **MNEMARCH™** — Attributes all stored data to a verified node anchor
- **ACCOUNTUM™** — Ledger entries reference the anchor hash as provenance
- **POLICUM™** — Boundary evaluations are scoped to verified node identities

---

## License

IDENTARCH™ is a licensed instrument of the ARCHONOMY™ discipline architecture.  
© Barkdale & Co. All rights reserved.  
Unauthorized reproduction or redistribution is prohibited.  
Derivative use requires a Class-1 Mechanism Engineer license.
