'use strict';

/**
 * INTENTUM™ — Intent Binding Driver
 * ARCHAI™ Governance Framework · Barkdale & Co.
 * Credential: ARCH-DA-001-2026
 *
 * Binds every execution action to a validated, provenance-tracked intent record.
 * No operation may proceed without a justified intent bound to a valid IDENTARCH anchor.
 * Halts model drift by ensuring every action has a traceable origination claim.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ── CONSTANTS ────────────────────────────────────────────────────────────────

const INTENTUM_VERSION = '1.0.0';
const ALGORITHM = 'sha256';
const ENCODING = 'hex';
const INTENT_EXPIRY_MS = 60 * 60 * 1000; // 1 hour default — intent is time-bounded

// ── INTENT CAPTURE ────────────────────────────────────────────────────────────

/**
 * Captures and binds an intent record to a validated IDENTARCH anchor.
 * This is the primary entry point. Must be called before any governed action.
 *
 * @param {object} anchor - Valid IDENTARCH anchor
 * @param {object} intentDescriptor - { action, justification, metadata }
 * @returns {object} intentRecord
 */
function captureIntent(anchor, intentDescriptor) {
  if (!anchor || !anchor.anchorHash || !anchor.nodeId) {
    throw new IntentumError('INTENT_NO_ANCHOR', 'A valid IDENTARCH anchor is required to capture intent.');
  }

  const now = Date.now();

  if (now > anchor.expiresAt) {
    throw new IntentumError('INTENT_ANCHOR_EXPIRED', `Anchor for node ${anchor.nodeId} has expired. Renew the anchor before capturing intent.`);
  }

  const { action, justification, metadata = {} } = intentDescriptor;

  if (!action || typeof action !== 'string') {
    throw new IntentumError('INTENT_NO_ACTION', 'An action string is required to capture intent.');
  }

  if (!justification || typeof justification !== 'string' || justification.trim().length < 10) {
    throw new IntentumError('INTENT_WEAK_JUSTIFICATION', 'A meaningful justification (min 10 chars) is required. Unjustified actions are not permitted.');
  }

  const intentId = crypto.randomUUID();
  const expiresAt = now + (metadata.expiryMs || INTENT_EXPIRY_MS);

  // Provenance hash — binds intent to anchor immutably
  const provenancePayload = JSON.stringify({
    intentId,
    anchorHash: anchor.anchorHash,
    nodeId: anchor.nodeId,
    action,
    justification: justification.trim(),
    capturedAt: now,
  });

  const provenanceHash = crypto
    .createHash(ALGORITHM)
    .update(provenancePayload)
    .digest(ENCODING);

  const intentRecord = {
    intentId,
    nodeId: anchor.nodeId,
    anchorHash: anchor.anchorHash,
    authority: anchor.authority,
    action,
    justification: justification.trim(),
    provenanceHash,
    capturedAt: now,
    expiresAt,
    metadata,
    status: 'BOUND',
    version: INTENTUM_VERSION,
    mechanism: 'INTENTUM',
  };

  return intentRecord;
}

// ── RUNTIME VALIDATION ────────────────────────────────────────────────────────

/**
 * Validates an intent record before an action executes.
 * Called at the execution boundary — the action gate.
 *
 * @param {object} intentRecord - From captureIntent()
 * @param {string} actionToExecute - The action about to run (must match intent)
 * @returns {object} validationResult
 */
function validateIntent(intentRecord, actionToExecute) {
  const validatedAt = Date.now();

  if (!intentRecord || !intentRecord.intentId) {
    return _failValidation(null, 'MISSING_INTENT_RECORD', validatedAt);
  }

  // Action must match exactly — no substitution permitted
  if (intentRecord.action !== actionToExecute) {
    return _failValidation(intentRecord.intentId, 'ACTION_MISMATCH', validatedAt);
  }

  // Intent must not be expired
  if (validatedAt > intentRecord.expiresAt) {
    return _failValidation(intentRecord.intentId, 'INTENT_EXPIRED', validatedAt);
  }

  // Intent must be in BOUND status
  if (intentRecord.status !== 'BOUND') {
    return _failValidation(intentRecord.intentId, `INTENT_STATUS_INVALID:${intentRecord.status}`, validatedAt);
  }

  // Recompute provenance hash to detect tampering
  const expectedPayload = JSON.stringify({
    intentId: intentRecord.intentId,
    anchorHash: intentRecord.anchorHash,
    nodeId: intentRecord.nodeId,
    action: intentRecord.action,
    justification: intentRecord.justification,
    capturedAt: intentRecord.capturedAt,
  });

  const expectedHash = crypto
    .createHash(ALGORITHM)
    .update(expectedPayload)
    .digest(ENCODING);

  if (expectedHash !== intentRecord.provenanceHash) {
    return _failValidation(intentRecord.intentId, 'PROVENANCE_HASH_TAMPERED', validatedAt);
  }

  return {
    valid: true,
    intentId: intentRecord.intentId,
    nodeId: intentRecord.nodeId,
    action: intentRecord.action,
    justification: intentRecord.justification,
    authority: intentRecord.authority,
    reason: 'INTENT_VALIDATED',
    validatedAt,
    mechanism: 'INTENTUM',
  };
}

// ── DYNAMIC CONSTRAINTS ───────────────────────────────────────────────────────

/**
 * Applies dynamic intention constraints to a set of intent records.
 * Enforces rules such as: no duplicate actions, no expired intents,
 * required justification patterns, action allowlists.
 *
 * @param {Array} intentRecords - Array of intent records to evaluate
 * @param {object} constraints - { allowedActions, requiredJustificationPattern, maxConcurrent }
 * @returns {object} constraintReport
 */
function applyConstraints(intentRecords, constraints = {}) {
  const now = Date.now();
  const {
    allowedActions = null,
    requiredJustificationPattern = null,
    maxConcurrent = null,
  } = constraints;

  const violations = [];
  const passing = [];

  for (const record of intentRecords) {
    const issues = [];

    // Expiry check
    if (now > record.expiresAt) {
      issues.push('CONSTRAINT_EXPIRED');
    }

    // Allowlist check
    if (allowedActions && !allowedActions.includes(record.action)) {
      issues.push(`CONSTRAINT_ACTION_NOT_ALLOWED:${record.action}`);
    }

    // Justification pattern check
    if (requiredJustificationPattern) {
      const pattern = new RegExp(requiredJustificationPattern, 'i');
      if (!pattern.test(record.justification)) {
        issues.push('CONSTRAINT_JUSTIFICATION_PATTERN_MISMATCH');
      }
    }

    if (issues.length > 0) {
      violations.push({ intentId: record.intentId, action: record.action, issues });
    } else {
      passing.push(record.intentId);
    }
  }

  // Concurrency check
  if (maxConcurrent !== null && passing.length > maxConcurrent) {
    violations.push({
      intentId: null,
      action: 'GLOBAL',
      issues: [`CONSTRAINT_MAX_CONCURRENT_EXCEEDED:limit=${maxConcurrent},active=${passing.length}`],
    });
  }

  return {
    evaluated: intentRecords.length,
    passing: passing.length,
    violations: violations.length,
    violationDetails: violations,
    constrainedAt: now,
    mechanism: 'INTENTUM',
  };
}

// ── INTENT REVOCATION ─────────────────────────────────────────────────────────

/**
 * Revokes an intent record, preventing it from being used for further actions.
 * Revoked intents are marked and cannot be reinstated.
 *
 * @param {object} intentRecord
 * @param {string} reason
 * @returns {object} revokedRecord
 */
function revokeIntent(intentRecord, reason = 'MANUAL_REVOCATION') {
  if (!intentRecord || !intentRecord.intentId) {
    throw new IntentumError('REVOKE_NO_RECORD', 'Cannot revoke: no intent record provided.');
  }

  return {
    ...intentRecord,
    status: 'REVOKED',
    revokedAt: Date.now(),
    revocationReason: reason,
    mechanism: 'INTENTUM',
  };
}

// ── PROVENANCE TRACKING ───────────────────────────────────────────────────────

/**
 * Builds a provenance chain from a sequence of intent records.
 * Shows the full audit trail of intentions for a node.
 *
 * @param {Array} intentRecords - Ordered array of intent records for a node
 * @returns {object} provenanceChain
 */
function buildProvenanceChain(intentRecords) {
  if (!Array.isArray(intentRecords) || intentRecords.length === 0) {
    throw new IntentumError('PROVENANCE_EMPTY', 'At least one intent record is required to build a provenance chain.');
  }

  const nodeIds = [...new Set(intentRecords.map(r => r.nodeId))];

  const chain = intentRecords.map((record, index) => ({
    sequence: index + 1,
    intentId: record.intentId,
    nodeId: record.nodeId,
    action: record.action,
    justification: record.justification,
    status: record.status,
    provenanceHash: record.provenanceHash,
    capturedAt: record.capturedAt,
    linkedTo: index > 0 ? intentRecords[index - 1].provenanceHash : null,
  }));

  // Chain integrity hash — binds all records together
  const chainPayload = chain.map(c => c.provenanceHash).join('|');
  const chainHash = crypto.createHash(ALGORITHM).update(chainPayload).digest(ENCODING);

  return {
    nodeIds,
    recordCount: chain.length,
    chainHash,
    chain,
    builtAt: Date.now(),
    mechanism: 'INTENTUM',
  };
}

// ── PERSISTENCE ───────────────────────────────────────────────────────────────

function persistIntent(intentRecord, outputDir = './intentum-store') {
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
  const filePath = path.join(outputDir, `${intentRecord.intentId}.intent.json`);
  fs.writeFileSync(filePath, JSON.stringify(intentRecord, null, 2), 'utf8');
  return filePath;
}

function loadIntent(intentId, storeDir = './intentum-store') {
  const filePath = path.join(storeDir, `${intentId}.intent.json`);
  if (!fs.existsSync(filePath)) {
    throw new IntentumError('INTENT_NOT_FOUND', `No persisted intent found for id: ${intentId}`);
  }
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

// ── ERROR CLASS ───────────────────────────────────────────────────────────────

class IntentumError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'IntentumError';
    this.code = code;
    this.mechanism = 'INTENTUM';
    this.timestamp = Date.now();
  }
}

// ── INTERNAL HELPERS ──────────────────────────────────────────────────────────

function _failValidation(intentId, reason, validatedAt) {
  return {
    valid: false,
    intentId,
    reason,
    validatedAt,
    mechanism: 'INTENTUM',
  };
}

// ── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  captureIntent,
  validateIntent,
  applyConstraints,
  revokeIntent,
  buildProvenanceChain,
  persistIntent,
  loadIntent,
  IntentumError,
  INTENTUM_VERSION,
};
