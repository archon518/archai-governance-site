'use strict';

/**
 * INTENTUM™ — Basic Usage Example
 * Requires: @archai/identarch (for anchor generation)
 */

// Simulate an IDENTARCH anchor (normally from identarch.generateAnchor())
const crypto = require('crypto');
const {
  captureIntent,
  validateIntent,
  applyConstraints,
  revokeIntent,
  buildProvenanceChain,
  persistIntent,
  loadIntent,
  IntentumError,
} = require('../src/intentum');

console.log('\n══════════════════════════════════════════');
console.log('  INTENTUM™ — Intent Binding Driver');
console.log('  ARCHAI™ Governance Framework');
console.log('  Barkdale & Co.');
console.log('══════════════════════════════════════════\n');

// Simulate a valid IDENTARCH anchor
const now = Date.now();
const mockAnchor = {
  nodeId: 'agent-node-001',
  role: 'EXECUTION_AGENT',
  authority: 'Barkdale & Co.',
  anchorHash: crypto.createHash('sha256').update('mock-anchor-001').digest('hex'),
  issuedAt: now,
  expiresAt: now + 86400000,
  mechanism: 'IDENTARCH',
};

// 1. Capture intent before an action
console.log('[1] Capturing intent...');
const intent = captureIntent(mockAnchor, {
  action: 'EXECUTE_PIPELINE_ROUTE_A',
  justification: 'Routing approved batch payload to primary processing pipeline per governance schedule.',
});
console.log('    ✓ Intent captured');
console.log('    Intent ID      :', intent.intentId);
console.log('    Action         :', intent.action);
console.log('    Provenance Hash:', intent.provenanceHash.slice(0, 24) + '...');
console.log('    Status         :', intent.status);

// 2. Validate intent at execution boundary
console.log('\n[2] Validating intent at execution gate...');
const validation = validateIntent(intent, 'EXECUTE_PIPELINE_ROUTE_A');
console.log('    ✓ Validation result:', validation.valid ? 'PASS' : 'FAIL');
console.log('    Reason         :', validation.reason);
console.log('    Authority      :', validation.authority);

// 3. Test action mismatch detection
console.log('\n[3] Testing action mismatch detection...');
const mismatch = validateIntent(intent, 'EXECUTE_UNAUTHORIZED_ROUTE_Z');
console.log('    ✓ Mismatch result:', mismatch.valid ? 'PASS (ERROR)' : 'FAIL (CORRECT)');
console.log('    Reason         :', mismatch.reason);

// 4. Test weak justification rejection
console.log('\n[4] Testing weak justification rejection...');
try {
  captureIntent(mockAnchor, {
    action: 'DELETE_ALL_RECORDS',
    justification: 'just do it',
  });
  console.log('    ERROR: Should have thrown');
} catch (e) {
  console.log('    ✓ Weak justification rejected:', e.code);
}

// 5. Apply dynamic constraints
console.log('\n[5] Applying dynamic constraints...');
const intent2 = captureIntent(mockAnchor, {
  action: 'EXECUTE_PIPELINE_ROUTE_B',
  justification: 'Secondary pipeline activation for load balancing per operational directive.',
});
const constraintReport = applyConstraints([intent, intent2], {
  allowedActions: ['EXECUTE_PIPELINE_ROUTE_A', 'EXECUTE_PIPELINE_ROUTE_B'],
  maxConcurrent: 3,
});
console.log('    ✓ Constraints applied');
console.log('    Evaluated      :', constraintReport.evaluated);
console.log('    Passing        :', constraintReport.passing);
console.log('    Violations     :', constraintReport.violations);

// 6. Build provenance chain
console.log('\n[6] Building provenance chain...');
const chain = buildProvenanceChain([intent, intent2]);
console.log('    ✓ Chain built');
console.log('    Records        :', chain.recordCount);
console.log('    Chain Hash     :', chain.chainHash.slice(0, 24) + '...');
chain.chain.forEach(c => {
  console.log(`    → [${c.sequence}] ${c.action} | linked: ${c.linkedTo ? c.linkedTo.slice(0,12) + '...' : 'ORIGIN'}`);
});

// 7. Revoke an intent
console.log('\n[7] Revoking intent...');
const revoked = revokeIntent(intent2, 'OPERATOR_OVERRIDE');
console.log('    ✓ Intent revoked');
console.log('    Status         :', revoked.status);
console.log('    Reason         :', revoked.revocationReason);

// Confirm revoked intent fails validation
const revokedValidation = validateIntent(revoked, 'EXECUTE_PIPELINE_ROUTE_B');
console.log('    Revoked validation:', revokedValidation.valid ? 'PASS (ERROR)' : 'FAIL (CORRECT)');
console.log('    Reason         :', revokedValidation.reason);

// 8. Persist and reload
console.log('\n[8] Persisting intent to disk...');
const filePath = persistIntent(intent, './intentum-store');
console.log('    ✓ Persisted to:', filePath);
const reloaded = loadIntent(intent.intentId, './intentum-store');
console.log('    ✓ Reloaded hash matches:', reloaded.provenanceHash === intent.provenanceHash);

console.log('\n══════════════════════════════════════════');
console.log('  All INTENTUM™ primitives operational.');
console.log('══════════════════════════════════════════\n');
